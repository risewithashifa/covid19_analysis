import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
data_csv = pd.read_csv(r"C:\Users\akhil\OneDrive\Desktop\covid19_analysis\data\country_wise_latest.csv")
top5 = data_csv.sort_values("Confirmed", ascending=False).head(5)
top5 = top5[['Country/Region', 'Confirmed', 'Deaths', 'Recovered']]
top5_melted = top5.melt(id_vars='Country/Region', 
                        value_vars=['Confirmed', 'Deaths', 'Recovered'], 
                        var_name='Status', 
                        value_name='Count')
plt.figure(figsize=(12, 6))
sns.barplot(data=top5_melted, 
            x='Country/Region', 
            y='Count', 
            hue='Status', 
            palette='Set2')
plt.title('Top 5 Countries - COVID-19 Confirmed, Deaths, and Recovered', fontsize=15, weight='bold')
plt.xlabel('Country', fontsize=12)
plt.ylabel('Number of Cases', fontsize=12)
plt.xticks(rotation=45)
plt.legend(title='Status', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()
