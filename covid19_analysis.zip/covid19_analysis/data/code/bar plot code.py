import pandas as pd
import matplotlib.pyplot as plt
data_csv=pd.read_csv(r"C:\Users\akhil\OneDrive\Desktop\covid19_analysis\data\country_wise_latest.csv")
top10 = data_csv.sort_values("Confirmed", ascending=False).head(10)
plt.figure(figsize=(10,6))
plt.bar(top10["Country/Region"], top10["Confirmed"], color='cyan',edgecolor='white')
plt.xticks(rotation=45,ha='right')
plt.xlabel("Country")
plt.ylabel('Confirmed cases')
plt.title("Top 10 Countries by Confirmed Cases")
plt.tight_layout()
plt.show()
