import pandas as pd
import matplotlib.pyplot as plt
data_csv=pd.read_csv(r"C:\Users\akhil\OneDrive\Desktop\covid19_analysis\data\country_wise_latest.csv")
data_csv.dropna(axis=0,inplace=True)
print(data_csv)
plt.hist(data_csv['Confirmed'],
         color = 'green',
         edgecolor = 'white',
         bins = 50)
plt.title('Distribution of confirmed COVID-19 cases')
plt.xlabel('confirmed cases')
plt.ylabel('number of countries')
plt.show()