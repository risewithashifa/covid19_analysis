import pandas as pd
import matplotlib.pyplot as plt
data_csv=pd.read_csv(r"C:\Users\akhil\OneDrive\Desktop\covid19_analysis\data\country_wise_latest.csv")
data_csv.dropna(axis=0,inplace=True)
print(data_csv)
plt.scatter(data_csv['Active'],data_csv['Deaths'],c='green')
plt.title('scatter plot of active vs deaths')
plt.xlabel('Active')
plt.ylabel('Deaths')
plt.show()