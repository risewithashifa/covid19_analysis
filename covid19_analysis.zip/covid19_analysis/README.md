##Covid19_analysis

##Project Description
This project analyzes COVID-19 data using Python and visualizes it with different types of plots.  
The dataset contains country-wise cases, and the visualizations help understand the spread of COVID-19 globally.


##Project Structure
 
  covid19_analysis/
     data/
       country_wise_cases.xlsx
       code/
          scatter_plot.py
          bar_plot.py
          histogram_plot.py
          seaborn_scatter.py
          grouped_bar_plot.py
       images/
          scatter_plot.png
          bar_plot.png
          histogram_plot.png
          seaborn_scatter.png
          grouped_bar_plot.png


##Features
- Analyze COVID-19 data country-wise.
- Visualize data using "matplotlib" and "seaborn".
- Generate:
  - Scatter plots
  - Bar plots
  - Histogram plots
  - Seaborn scatter plots
  - Grouped bar plots


##Libraries Used
- pandas
- matplotlib
- seaborn


##How to Run
1. Clone this repository or download the project.
2. Open the 'code' folder.
3. Run any '.py' file to generate the respective plot.
4. Check the generated plots inside the 'images' folder.


##MINI PROJECT BY...
SHAIK ASHIFA HARFATH